<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User; // Certifique-se de que o modelo Usuario está corretamente referenciado

class AuthController extends Controller
{
    // Mostra o formulário de login
    public function showLoginForm()
    {
        return view('auth.login'); // A view deve existir em resources/views/auth/login.blade.php
    }

    // Realiza o login do usuário
    public function login(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'senha' => 'required',
    ]);

    // Tenta autenticar o usuário com as colunas definidas
    if (Auth::attempt(['Email' => $request->email, 'Senha' => $request->senha])) {
        return redirect()->intended('/register'); // Redireciona após login bem-sucedido
        return back()->withErrors([
            'email' => 'As credenciais fornecidas estão incorretas.',
        ])->onlyInput('email');
    }
}

    // Mostra o formulário de registro
    public function showRegistrationForm()
    {
        return view('auth.register'); // A view deve existir em resources/views/auth/register.blade.php
    }

    // Realiza o registro do usuário
    public function register(Request $request)
    {
        // Validação dos dados do registro
        $request->validate([
            'nome' => 'required|string|max:120',
            'email' => 'required|string|email|max:100|unique:USUARIO',
            'cpf' => 'required|string|size:11|unique:USUARIO',
            'endereco' => 'nullable|string|max:255',
            'senha' => 'required|string|min:8|confirmed',
        ]);
        

        // Cria um novo usuário
        User::create([
            'Nome' => $request->nome,
            'Email' => $request->email,
            'Cpf' => $request->cpf,
            'Endereco' => $request->endereco,
            'Senha' => bcrypt($request->senha), // Criptografa a senha
        ]);

        // Autentica o usuário recém-registrado
        Auth::attempt(['Email' => $request->email, 'Senha' => $request->senha]);

        // Redireciona para a rota protegida
        return redirect()->intended('/login');
    }

    // Realiza o logout do usuário
    public function logout(Request $request)
    {
        Auth::logout();

        // Redireciona após o logout
        return redirect('/login')->with('success', 'Você foi desconectado com sucesso.');
    }
}
