<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable; // Usa a classe base de autenticação
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $table = 'USUARIO'; // Nome da tabela

    public $timestamps = false; // Se não houver timestamps no banco

    protected $fillable = [
        'Nome', 'Email', 'Cpf', 'Endereco', 'Senha',
    ];

    // Defina a coluna da senha como `password`
    protected $hidden = [
        'Senha', // Oculta a senha ao serializar
    ];

    // Método para garantir que o campo `password` seja usado para autenticação
    public function getAuthPassword()
    {
        return $this->Senha;
    }
}